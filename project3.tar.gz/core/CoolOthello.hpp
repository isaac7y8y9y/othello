#include "OthelloAI.hpp"

namespace yencn
{
	class CoolOthello : public OthelloAI
	{
	public: 
		virtual std::pair<int, int> chooseMove(const OthelloGameState& state);
	private:
		int search(OthelloGameState& s, std::pair<int,int> movecoord, int depth, bool IamBlack);
		int evaluate(OthelloGameState& s, std::pair<int, int> movecoord,bool IamBlack, int b, int w);


	//private:
		//int evaluate(const OthelloGameState& state);

	};
}