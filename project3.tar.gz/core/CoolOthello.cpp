#include <ics46/factory/DynamicFactory.hpp>
#include "CoolOthello.hpp"
#include "OthelloBoard.hpp"
#include "OthelloGameState.hpp"
#include "OthelloException.hpp"
#include "OthelloCell.hpp"
#include <iostream>
#include <algorithm>
ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, yencn::CoolOthello, "SuperOthello (required)");

std::pair<int, int> yencn::CoolOthello::chooseMove(const OthelloGameState& state)
{
	std::cout << "Big Game" << std::endl;
	std::unique_ptr<OthelloGameState> tstate = state.clone();
	const OthelloBoard& gameboard = tstate->board();
	bool IamBlack = tstate->isBlackTurn();
	std::vector<std::pair<int, int>> themove;
	//std::cout << "I am Black " << IamBlack << std::endl;
	int biggest=0;
	int locate=0;
	for(int x = 0; x<=gameboard.width()-1; ++x)
	{
		for(int y = 0; y<=gameboard.height()-1; ++y)
		{
			if(tstate->isValidMove(x, y)==true)
			{
				//std::cout << "I can do " << x << " : " << y << std::endl;
				themove.push_back(std::make_pair(x, y));
			}

		}
	}
	for(int i = 0; i< themove.size(); ++i)
	{
		
		try
		{
			std::pair<int, int> newcoord = themove[i];
			std::cout << "my turn" << std::endl;
			tstate->makeMove(newcoord.first, newcoord.second);
			//std::cout << "my move" << std::endl;
			//std::cout << "themove size is " << themove.size() << std::endl;
			int moveval = search(*tstate, themove[i], 3, IamBlack); //previously 
			//if((newcoord.first==0 && newcoord.second==0)||newcoord.second)

			if(i == 0)
			{
				biggest = moveval;
			}
			else if(moveval>biggest)
			{
				biggest = moveval;
				locate = i;
			}
		}
		catch(OthelloException& e)
		{
			//std::cout << "My input is wrong" << std::endl;
		}


	}
	std::pair<int, int> mymove = themove[locate];
	std::cout << "I shall return " << mymove.first << " : " << mymove.second << std::endl;
	return mymove;


}

int yencn::CoolOthello::evaluate(OthelloGameState& s, std::pair<int, int> movecoord, bool IamBlack, int b, int w)
{
	int me;
	int you;
	if(IamBlack==true && s.isBlackTurn()==true)
	{
		me=b;
		you=w;
	}
	else if(IamBlack==false && s.isBlackTurn()==false)
	{
		me=w;
		you=b;
	}
	else if(IamBlack==true && s.isBlackTurn()==false)
	{
		me=b;
		you=w;
	}
	else
	{
		me=w;
		you=b;
	}
	const OthelloBoard& setup=s.board();

	if(setup.isValidCell(movecoord.first-1, movecoord.second-1)==true &&
		setup.isValidCell(movecoord.first, movecoord.second-1)==true &&
		setup.isValidCell(movecoord.first+1, movecoord.second-1)==true &&
		setup.isValidCell(movecoord.first+1, movecoord.second)==true &&
		setup.isValidCell(movecoord.first+1, movecoord.second+1)==true &&
		setup.isValidCell(movecoord.first, movecoord.second+1)==true &&
		setup.isValidCell(movecoord.first-1, movecoord.second+1)==true &&
		setup.isValidCell(movecoord.first-1, movecoord.second)==true)
	{

		//for stable diagonal
		if(setup.cellAt(movecoord.first-1, movecoord.second-1)==setup.cellAt(movecoord.first, movecoord.second)||setup.cellAt(movecoord.first+1, movecoord.second-1)==setup.cellAt(movecoord.first, movecoord.second)||
			setup.cellAt(movecoord.first-1, movecoord.second+1)==setup.cellAt(movecoord.first, movecoord.second)||setup.cellAt(movecoord.first+1, movecoord.second+1)==setup.cellAt(movecoord.first, movecoord.second))
		{
			if((IamBlack==true && s.isBlackTurn()==true)||(IamBlack==false && s.isBlackTurn()==false))
				me=me+6;
			else
				you=you+6;
		}
		//for stable horizontal
		else if(setup.cellAt(movecoord.first-1, movecoord.second)==setup.cellAt(movecoord.first, movecoord.second)||setup.cellAt(movecoord.first, movecoord.second-1)==setup.cellAt(movecoord.first, movecoord.second)||
			setup.cellAt(movecoord.first+1, movecoord.second)==setup.cellAt(movecoord.first, movecoord.second)||setup.cellAt(movecoord.first, movecoord.second+1)==setup.cellAt(movecoord.first, movecoord.second))
		{
			if((IamBlack==true && s.isBlackTurn()==true)||(IamBlack==false && s.isBlackTurn()==false))
				me=me+7;
			else
				you=you+7;
		}
		//for diagonal empty cell
		else if(setup.cellAt(movecoord.first-1, movecoord.second-1)!=OthelloCell{0}||setup.cellAt(movecoord.first+1, movecoord.second-1)!=OthelloCell{0}||
			setup.cellAt(movecoord.first-1, movecoord.second+1)!=OthelloCell{0}||setup.cellAt(movecoord.first+1, movecoord.second+1)!=OthelloCell{0})
		{
			if((IamBlack==true && s.isBlackTurn()==true)||(IamBlack==false && s.isBlackTurn()==false))
				me=me+7;
			else
				you=you+7;
		}

	}

	else
	{
		//attack corner
		if((movecoord.first==0 && movecoord.second==0) || (movecoord.first==setup.width()-1 && movecoord.second==0) 
			|| (movecoord.first==0 && movecoord.second==setup.height()-1) || (movecoord.first==setup.width()-1 && movecoord.second == setup.height()-1))
		{
			if((IamBlack==true && s.isBlackTurn()==true)||(IamBlack==false && s.isBlackTurn()==false))
				me=me+9;
			else
				you=you+9;
		}

		else if(movecoord.first==0 || movecoord.second==0 || movecoord.first==setup.width()-1 || movecoord.first == setup.height()-1)
		{
			if((IamBlack==true && s.isBlackTurn()==true)||(IamBlack==false && s.isBlackTurn()==false))
				me=me+9;
			else
				you=you+9;
		}
	}

	int score=me-you;
	return score;



}

int yencn::CoolOthello::search(OthelloGameState& s, std::pair<int, int> movecoord, int depth, bool IamBlack)
{
	

	if(depth == 0)
	{

		int score;
		std::unique_ptr<OthelloGameState> ns = s.clone();
		score = evaluate(*ns, movecoord, IamBlack, s.blackScore(), s.whiteScore());
		return score;

	}
	else
	{
//seg fault all good ||
		std::unique_ptr<OthelloGameState> ns = s.clone();
		const OthelloBoard& setup = ns->board();
		if(IamBlack == s.isBlackTurn())
		{	

			std::vector<std::pair<int,int>> myplay;
			std::cout << "my turn " << std::endl;
			int bestval = 0;
			for(int x = 0; x<=setup.width()-1; ++x)
			{
				for(int y = 0; y<=setup.height()-1; ++y)
				{
					if(ns->isValidMove(x, y)==true)
					{
						myplay.push_back(std::make_pair(x, y));
					}
				}
			}
			for(int i=0; i< myplay.size(); ++i)
			{
				std::pair<int, int> c = myplay[i];
				try
				{
					ns->makeMove(c.first, c.second);
					//std::cout << "I move" << std::endl;
					int emove =search(*ns, c, depth-1, IamBlack);

					if(i==0)
						bestval = emove;
					if(emove>bestval)
						bestval = emove;
				}
				catch(OthelloException& e)
				{
					//std::cout << "My input is wrong" << std::endl;
				}

			}
			return bestval;

		}
		else
		{
			std::vector<std::pair<int,int>> myplay;
			std::cout << "Not my Turn"  << std::endl;
			int worstval=0;
			for(int x = 0; x<=setup.width()-1; ++x)
			{
				for(int y = 0; y<=setup.height()-1; ++y)
				{
					if(ns->isValidMove(x, y)==true)
					{
						myplay.push_back(std::make_pair(x, y));
					}
				}
			}
			for(int i= 0; i< myplay.size(); ++i)
			{
				std::pair<int, int> c=myplay[i];
				try
				{
					ns->makeMove(c.first, c.second);

					int emove = search(*ns, c, depth-1, IamBlack);

					if(i==0)
					{
						worstval = emove;
					}
					if(emove<worstval)
					{
						worstval = emove;
					}
					

				}
				catch(OthelloException& e)
				{
					//std::cout << "This input is wrong" << std::endl;
				}

			}
			return worstval;
		}

	}
}