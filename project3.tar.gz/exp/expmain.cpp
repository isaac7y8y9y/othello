// expmain.cpp
//
// ICS 46 Spring 2018
// Project #3: Black and White
//
// Do whatever you'd like here.  This is intended to allow you to experiment
// with the given classes in the othellogame library, or with your own
// algorithm implementations, outside of the context of the GUI or
// Google Test.
#include "CoolOthello.hpp"
#include "OthelloGameStateFactory.hpp"
#include "OthelloGameState.hpp"
#include <iostream>
int main()
{
	/*
	OthelloGameState& a();
	std::unique_ptr<OthelloGameState> mygame = a.makeNewGameState(8, 8);
	std::pair<int, int> coord = yencn::CoolOthello::chooseMove(*mygame);
	std::cout << coord.first << " " << coord.second << std::endl;
	*/
    return 0;
}

